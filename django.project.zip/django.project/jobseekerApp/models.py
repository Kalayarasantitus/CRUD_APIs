from django.db import models

class Job_Seeker(models.Model):
    job_id = models.CharField(max_length=100)
    name = models.CharField(max_length = 30)
    mobile = models.CharField(max_length=100)

class admin_user(models.Model):
    user_id=models.CharField(max_length=100)
    name=models.CharField(max_length=50)
    email=models.CharField(max_length=100)

class job(models.Model):
    job_id=models.CharField(max_length=50)
    job_title=models.CharField(max_length=50)
    job_description=models.CharField(max_length=100)




