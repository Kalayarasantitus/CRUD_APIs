from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from jobseekerApp.serializers import JobseekerSerializer
from jobseekerApp.models import Job_Seeker
from jobseekerApp.serializers import AdminUserSerializer
from jobseekerApp.models import admin_user
from jobseekerApp.serializers import jobSerializer
from jobseekerApp.models import job


@csrf_exempt
def jobseekerApi(request,id=0):
    global Job_Seeker
    if request.method=='GET':
        Job_Seeker1= Job_Seeker.objects.all()
        Job_Seeker_serializer=JobseekerSerializer(Job_Seeker1,many=True)
        return JsonResponse(Job_Seeker_serializer.data,safe=False)
    
    elif request.method=='POST':
        Job_Seeker_data=JSONParser().parse(request)
        Job_Seeker_serializer1=JobseekerSerializer(data=Job_Seeker_data)
        if Job_Seeker_serializer1.is_valid():
            Job_Seeker_serializer1.save()
            return JsonResponse("Added Successfully",safe=False)
        return JsonResponse("Failed to Add",safe=False)
    

    elif request.method=='PUT':
        Job_Seeker_data=JSONParser().parse(request)
        Job_Seeker2=Job_Seeker.objects.get(id=id)
        Job_Seeker_serializer2=JobseekerSerializer(Job_Seeker2,data=Job_Seeker_data)
        if Job_Seeker_serializer2.is_valid():
            Job_Seeker_serializer2.save()
            return JsonResponse("Updated Successfully",safe=False)
        return JsonResponse("Failed to Update")
    
    elif request.method=='DELETE':
        Job_Seeker=Job_Seeker.objects.get(id=id)
        Job_Seeker.delete()
        return JsonResponse("Deleted Successfully",safe=False)
    


@csrf_exempt
def AdminUserApi(request,id=0):
    global admin_user
    if request.method=='GET':
        Admin_User1= admin_user.objects.all()
        Admin_User_serializer=AdminUserSerializer(Admin_User1,many=True)
        return JsonResponse(Admin_User_serializer.data,safe=False)
    
    elif request.method=='POST':
        Admin_User_data=JSONParser().parse(request)
        Admin_User_serializer1=AdminUserSerializer(Admin_User_data)
        if Admin_User_serializer1.is_valid():
            Admin_User_serializer1.save()
            return JsonResponse("Added Successfully",safe=False)
        return JsonResponse("Failed to Add",safe=False)
    

    elif request.method=='PUT':
        Admin_User_data=JSONParser().parse(request)
        Admin_User2=admin_user.objects.get(id=id)
        Admin_User_serializer2=AdminUserSerializer(Admin_User2,data=Admin_User_data)
        if Admin_User_serializer2.is_valid():
            Admin_User_serializer2.save()
            return JsonResponse("Updated Successfully",safe=False)
        return JsonResponse("Failed to Update")
    
    elif request.method=='DELETE':
        Admin_User=admin_user.objects.get(id=id)
        Admin_User.delete()
        return JsonResponse("Deleted Successfully",safe=False)
    


@csrf_exempt
def jobApi(request,id=0):
    global job
    if request.method=='GET':
        job1= job.objects.all()
        job_serializer=jobSerializer(job1,many=True)
        return JsonResponse(job_serializer.data,safe=False)
    
    elif request.method=='POST':
        job_data=JSONParser().parse(request)
        job_serializer1=jobSerializer(job_data)
        if job_serializer1.is_valid():
            job_serializer1.save()
            return JsonResponse("Added Successfully",safe=False)
        return JsonResponse("Failed to Add",safe=False)
    

    elif request.method=='PUT':
        job_data=JSONParser().parse(request)
        job2=job.objects.get(id=id)
        job_serializer2=jobSerializer(job2,data=job_data)
        if job_serializer2.is_valid():
            job_serializer2.save()
            return JsonResponse("Updated Successfully",safe=False)
        return JsonResponse("Failed to Update")
    
    elif request.method=='DELETE':
        job3=job.objects.get(id=id)
        job3.delete()
        return JsonResponse("Deleted Successfully",safe=False)