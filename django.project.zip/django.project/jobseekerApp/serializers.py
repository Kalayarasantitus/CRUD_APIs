from rest_framework import serializers
from jobseekerApp.models import Job_Seeker,admin_user,job

class JobseekerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Job_Seeker
        fields = '__all__'


class AdminUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = admin_user
        fields = '__all__'

class jobSerializer(serializers.ModelSerializer):
    class Meta:
        model = job
        fields = '__all__'
