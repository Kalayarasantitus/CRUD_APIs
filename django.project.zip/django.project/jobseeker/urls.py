from django.contrib import admin
from django.urls import path,include,re_path 
from django.urls import re_path as url
from jobseekerApp import views

urlpatterns = [
    url(r'^Job_Seeker$',views.jobseekerApi),
    url(r'^Job_Seeker$',views.jobseekerApi),
    url(r'^Job_Seeker/([0-9]+)$',views.jobseekerApi),
    path('admin/', admin.site.urls),
    url(r'^admin_user$',views.AdminUserApi),
    url(r'^admin_user$',views.AdminUserApi),
    url(r'^admin_user/([0-9]+)$',views.AdminUserApi),
    url(r'^job$',views.jobApi),
    url(r'^job$',views.jobApi),
    url(r'^job/([0-9]+)$',views.jobApi),
    
]









